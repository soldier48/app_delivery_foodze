package com.exarcplus.foodzeetest2.NavDraw.NotificationsActivity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

import com.exarcplus.foodzeetest2.NavDraw.HomeActivity.HomeScreen.SpecialOffers.SpecialOfferAdapter;
import com.exarcplus.foodzeetest2.NavDraw.HomeActivity.HomeScreen.SpecialOffers.SpecialOffersModel;
import com.exarcplus.foodzeetest2.R;

import java.util.ArrayList;
import java.util.Arrays;

public class NotificationsActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<NotificationsModel> notificationsModel = new ArrayList<>();
    NotificationsAdapter notificationsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        recyclerView = (RecyclerView) findViewById(R.id.recycler_notifications);
        notificationsAdapter();

        NotificationsModel notificationsModel1 = new NotificationsModel("Your Order Delivered Just Now", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam id velit aliquam tortor sodales convallis nec ac nulla.", R.drawable.ic_notification);
        notificationsModel.add(notificationsModel1);

        NotificationsModel notificationsModel2 = new NotificationsModel("Your Rating Has Been Posted", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam id velit aliquam tortor sodales convallis nec ac nulla.", R.drawable.ic_notification);
        notificationsModel.add(notificationsModel2);

        NotificationsModel notificationsModel3 = new NotificationsModel("Your Order Delivered Just Now", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam id velit aliquam tortor sodales convallis nec ac nulla.", R.drawable.ic_notification);
        notificationsModel.add(notificationsModel3);

        NotificationsModel notificationsModel4 = new NotificationsModel("Your Order Confirmed", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam id velit aliquam tortor sodales convallis nec ac nulla.", R.drawable.ic_notification);
        notificationsModel.add(notificationsModel4);


        //Calling home fragment
        ImageView back = (ImageView) findViewById(R.id.backtopreviouspage);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    ///Notifications///
    public void notificationsAdapter(){
        NotificationsAdapter notificationsAdapter = new NotificationsAdapter(this, notificationsModel);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 1);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(notificationsAdapter);
    }
}
