package com.exarcplus.foodzeetest2.NavDraw.HomeActivity.HomeScreen.SearchView;

/**
 * Created by Parsania Hardik on 28-Jun-17.
 */
public class Model {

    private String name;
    private int image_drawable;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
