package com.exarcplus.foodzeetest2.NavDraw.MyProfileActivity.MyProfileEditActivity;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public class MyGlideModule extends AppGlideModule {
}
